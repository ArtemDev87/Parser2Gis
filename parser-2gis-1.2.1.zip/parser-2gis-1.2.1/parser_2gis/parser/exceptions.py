class ParserException(Exception):
    pass


__all__ = [
    'ParserException',
]
