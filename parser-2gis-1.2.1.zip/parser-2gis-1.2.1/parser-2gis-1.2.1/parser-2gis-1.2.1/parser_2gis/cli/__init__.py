from .app import cli_app

__all__ = [
    'cli_app',
]
