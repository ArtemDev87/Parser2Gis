from .app import gui_app

__all__ = [
    'gui_app',
]
