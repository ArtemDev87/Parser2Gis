"""Version info."""

version = '1.2.1'
config_version = '0.1'
