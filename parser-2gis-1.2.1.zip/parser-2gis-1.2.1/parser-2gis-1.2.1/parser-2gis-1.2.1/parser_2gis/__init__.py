from .main import main
from .version import version as __version__

__all__ = [
    'main',
    '__version__',
]
